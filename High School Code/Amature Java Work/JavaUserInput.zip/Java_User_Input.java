//Jakary Ivery
import java.util.Scanner;
public class Main {
/*  
    Challenge 1:
    Write a function that takes a persons first name and prints
    a greeting using the first name. Example: "Hello Julie"
*/
  static void myName() {
    Scanner myObj = new Scanner(System.in);
    System.out.println("What Is Your Name Type it below  ↓ ↓");

    String Name = myObj.nextLine();
    System.out.println("Hello " + Name);
  }
/*  
    Challenge 2:
    Write a function that calculates the area of a rectangle. Determine what parameters
    the function needs and what gets returned.
*/
  static void myRec() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Enter the width of the Rectangle:");
    double base = scanner.nextDouble();

    System.out.println("Enter the height of the Rectangle:");
    double height = scanner.nextDouble();

    double area = (base* height)/2;
    System.out.println("Area of Rectangle is: " + area);      

  }
  /*  
    Challenge 3:
    Write a function takes a whole number, say n,  and returns the sum from 1 to n
  */
  static void mySum(){
    int num = 1, count = 1, total = 0;

    while(count <= num){
     total = total + count;
     count++;
}

System.out.println("the sum from 1 to n is: "+total);
  
}
/*  
    Challenge 4:
    Write a function that takes creates and returns a username. The username consist of
    the first letter of a students first name, the lastname and the last four digits of their OSIS.
    For Example: first name: Jack, last name: Cheatch and OSIS No: 123456789, the function
    should return "JCheatch6789"
*/
  
static void myCut(){
    Scanner myObj1 = new Scanner(System.in);  
    System.out.println("Enter first name ");

    String userFirstName = myObj1.nextLine(); 
    System.out.println(" your first name is " + userFirstName);

    Scanner myObj2 = new Scanner(System.in);  
    System.out.println("Enter Last name ");

    String userLastName = myObj2.nextLine(); 
    System.out.println(" your Last name is " + userLastName);

    Scanner myObj3 = new Scanner(System.in);  
    System.out.println("Enter the Last 4 digits of your OSIS number ");

    String userLastDig = myObj3.nextLine(); 
    System.out.println(" your Last 4 digits of your OSIS number is " + userLastDig );

    String cut = userFirstName.substring(0,1);

    System.out.println(cut+userLastName+userLastDig); 
}
/*  
    Challenge 5:
    Write a function that counts the number of occurances a pattern appears in a string.
    Have the function take in the string and the pattern you are looking for.
    Example: string: "aaBBaaccAA" and the pattern: "aa" the function will return 2.
*/
static void myCount(){
String str = "I Love to program while listening to music when I watch Mr.Porchetta program I learn I want to program till I die";
 
int count = ( str.split("program", -1).length ) - 1;
 
System.out.println("Total occurrences: " + count);
}
/*  
    Bonus Challenge:
    Write a function that takes string and returns a string in reverse order.
       Example: "Hello" --> "olleH"
*/
static void myReverse(){
   System.out.println("Enter string to become reversed:");
 
 Scanner read = new Scanner(System.in);
 String str = read.nextLine();
 String reverse = "";
 
 
 for(int i = str.length() - 1; i >= 0; i--)
 {
 reverse = reverse + str.charAt(i);
 }
 
 System.out.println("Here You Go:");
 System.out.println(reverse);
}

  public static void main(String[] args) {
    myName();
    myRec();
    mySum();
    myCut();
    myCount();
    myReverse();
  }
}

//Jakary Ivery 