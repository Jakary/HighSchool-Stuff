import java.util.Scanner;
import java.util.Random;

class Main {
  public static void main(String[] args) {
    // **************************************************
    // **** All your code must be written below here ****
    // **************************************************

    //Always prompt the user for what information you are requesting


/*  
    Challenge 1:
    Write the jave code to generate a random number from 0 to 9 (inclusive) and print out a generate number

    Write the jave code to generate a random number from 1 to 20 (inclusive)and print out a generate number

*/
for(int i=0; i<1; i++){
  System.out.println(Math.round(Math.random()*9)+1);
}

for(int i=0; i<1; i++){
  System.out.println(Math.round(Math.random()*20)+1);
}

/*  
    Challenge 2:
    Generate a random secret number from 1 to 15 secret number.
    Ask the user to guess the number. Allow the user to keep trying to 
    guess the number until they guess it. 
*/


int secretNumber;


    secretNumber = (int) (Math.random() * 15 + 1);           
        Scanner keyboard = new Scanner(System.in);

          int guess;

            do {

    System.out.print("ENTER A NUMBER 1 THROUGH 15 ( ❛ ͜ʖ ❛ ) : ");

          guess = keyboard.nextInt();

    if (guess == secretNumber)

      System.out.println("Your guess is correct. Congratulations!");

  else if (guess < secretNumber)

  System.out

  .println("Your guess is smaller than the secret number.");

  else if (guess > secretNumber)

  System.out
  .println("Your guess is greater than the secret number.");

} while (guess != secretNumber);



/*  
    Challenge 3:
    Generate a random secret number from 5 to 25 secret number.
    Ask the user to guess the number. Allow the user only 4 tries to guess otherwise they lose. 
*/
Random randomNumber = new Random();

int correctNumber;

int guessTracker;

int guessLimit = 4;

int userInput;

  Scanner in = new Scanner(System.in);

    int game = 1;

      boolean winTracker = false;

         

while (1 == game){

  correctNumber  = randomNumber.nextInt(25);

      userInput = 0;

            guessTracker = 0;

             

        System.out.println("Please guess the number between 5 and 25: ");

        while (correctNumber != userInput && guessTracker < guessLimit){

             

            userInput = in.nextInt();

            guessTracker++;

                 

        if (userInput == correctNumber){

            System.out.println("You have won the game!");

            System.out.println("The correct number was " + correctNumber);

            System.out.println("It took a total of " + guessTracker + " guesses");

        }

         

        else if (userInput < correctNumber){

            System.out.println("The number is higher than your guess");

            System.out.println("Please enter your next guess: ");

        }

         
        else if (userInput > correctNumber){

            System.out.println("The number is lower than your guess");

            System.out.println("Please enter your next guess: ");

            }

        }

         

        if (correctNumber != userInput){

            System.out.println("No more guesses tough beans! ( ᵔ ͜ʖ ᵔ ) The correct number was: " + correctNumber);

        }

         

    }

 



/*  
    *** Bonus Challenge ***:

    If you invested $1000 at 5% per year. How many years would it take for the investment to grow to at least:

    a) $1500
    5 months
    b) $2000
    1 year
    c) $3000
    3years

*/







    // **************************************************
    // **** Don't write any code below here.  ***********
    // **************************************************

  }
}

