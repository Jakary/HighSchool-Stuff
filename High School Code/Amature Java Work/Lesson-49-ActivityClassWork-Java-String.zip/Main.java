public class Main{
  
    
  public static void main(String[]args){
    Dog poodle = new Dog("poodle");
    System.out.println(poodle.name);
    Dog poodle2 = new Dog("fake poodle");
    System.out.println(poodle2.name);


    if (poodle.name == "poodle"){
      System.out.println("I am a poodle");
    }

 

  }
  
}