public class poodle extends Dog{

public final boolean standardPoodle;

poodle(boolean standardPoodle , String name){
  super(name);
  this.standardPoodle = standardPoodle;
}

}