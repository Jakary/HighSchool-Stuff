public class Dog{

  public final String name;

  Dog(String name){
    this.name = name;
  }
public String getName(){
    return name;
  }


}