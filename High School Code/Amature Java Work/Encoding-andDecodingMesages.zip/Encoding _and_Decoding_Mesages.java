//Jakary Ivery
import java.util.*; 
public class Main { 
	public static void main(String[] args) {
  // **************************************************
  // **** Call your function to test them in the   ****
  // **** main function here.                     ****
  // ************************************************** 
  String msg ="aBcDeF";
  String encodedMsg = encode(msg);
  System.out.println("Original msg: "+msg);
  System.out.println("encoded msg: "+encodedMsg);

  /*  
    Challenge 1:
    Write a function, called "decode", that takes the string that function encode returns, "encodedMsg" and 
    returns the original message.Hint: shift left
  */
	String sample = "MR.PORCHETA'S COMPUTER SCIENCE CLASS PERIOD 8"; 
	System.out.println("Sample String:"+ sample); 
	String BasicBase64format = Base64.getEncoder() 
	.encodeToString(sample.getBytes()); 
	System.out.println("Encoded String:"+ BasicBase64format); 




	} 
  static String encode(String txt){
  String result="";
  int ascii;
    for(int x=0; x<=txt.length()-1;x++){
      ascii=(int)txt.charAt(x) - 1;
      result = result + (char)ascii;
    }
    return result;
  }
    /*  
    Challenge 2:
    The function encode will convert a character 'z' to '{' and 'Z' to '['. We want instead to convert 'z' to 'a' and 'Z' to 'A'. Make the changes to the functions encode and decode so we create this affect.
  */
  // **************************************************
  // **** Don't write any code below here.  ***********
  // **************************************************
} 
