import java.util.*;
class Main {
  public static void main(String[] args) {
    // **************************************************
    // **** Call your function to test them in the   ****
    // **** main function here.                     ****
    // **************************************************


  

  // Write you functions below here


  /*  
    Challenge 1:
    Write a function that takes a persons first name and prints
    a greeting using the first name. Example: "Hello Julie"
  */

 Scanner in = new Scanner(System.in);
 System.out.print(" Hey What's You're Name: ");
 String name = in.nextLine();
 System.out.println("Hello "+name);

 
  
  /*  
    Challenge 2:
    Write a function that calculates the area of a rectangle. Determine what parameters
    the function needs and what gets returned.
  */
  Scanner scanner = new Scanner(System.in);

  System.out.println("Enter the width of the Triangle:");
   double base = scanner.nextDouble();

    System.out.println("Enter the height of the Triangle:");
      double height = scanner.nextDouble();

      double area = (base* height)/2;
      System.out.println("Area of Triangle is: " + area);      

  /*  
    Challenge 3:
    Write a function takes a whole number, say n,  and returns the sum from 1 to n
  */
int num = 1, count = 1, total = 0;

while(count <= num){
 total = total + count;
    count++;
}

System.out.println("the sum from 1 to n is: "+total);
  
  /*  
    Challenge 4:
    Write a function that takes creates and returns a username. The username consist of
    the first letter of a students first name, the lastname and the last four digits of their OSIS.
    For Example: first name: Jack, last name: Cheatch and OSIS No: 123456789, the function
    should return "JCheatch6789"
  */
  

  


  /*  
    Challenge 5:
    Write a function that counts the number of occurances a pattern appears in a string.
    Have the function take in the string and the pattern you are looking for.
    Example: string: "aaBBaaccAA" and the pattern: "aa" the function will return 2.
  */


  



  /*  
    Bonus Challenge:
    Write a function that takes string and returns a string in reverse order.
       Example: "Hello" --> "olleH"
  */
   




  // **************************************************
  // **** Don't write any code below here.  ***********
  // **************************************************
  }
}