let link="https://api.openweathermap.org/data/2.5/weather?&appid=1135228a3da543c6a87fbe2ea6fc5bdf&units=imperial&q="

let link2 ="https://api.openweathermap.org/data/2.5/forecast/daily?appid=1135228a3da543c6a87fbe2ea6fc5bdf&units=imperial&cnt=5&q="

function search(){
  let city = document.getElementById("city").value
  let state = document.getElementById("state").value
  let country = document.getElementById("country").value


  let location = `${city},${country},${state}`
  $.getJSON(link + location,function(data){
  console.log(data);
  displayCurrentWeather(data);
  })
  $.getJSON(link2 + location,function(data){
    console.log(data)
    dispaly5DayForecast(data)
  })
}
function displayInfo(data){
  let output = document.getElementById("output");
  let build="";
  build +=`<div class="current temp">`
  build +=`   <h3>${data.name} (${data.coord.lon},${data.coord.lat})</h3>`
  build +=`<hr>`
  build += `<p>Temp ${data.main.temp}</p>`
  build +=`</div>`
output.innerHTML = build;
}
function displayCurrentWeather(data){}
function dispaly5DayForecast(data){
  console.log(data.list[0])
  let build=""

for(let index=0;index<data.list.length;index++){
build+=`<div class="cards">`
build+=`<p>Day:${data.list[index].temp.day}(${data.list[index].feels_like.day})</p>`
build+=`</div>`
}
output.innerHTML=build;
}



