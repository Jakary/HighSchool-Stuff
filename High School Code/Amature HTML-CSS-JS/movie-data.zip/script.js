let link = "https://api.themoviedb.org/3/search/movie?api_key=58e42380169b17585c0a25d4de31e8ff&query="

let movies = document.getElementById("movie");

function search(){

  let movie = document.getElementById("movie").value;

  $.getJSON(link + movie,function(data){
   
    displayCards(data)

  })
}
function displayCards(data){

  let output = document.getElementById("output");
  let build = ""

  for(let index = 0; index < data.results.length; index++){

    build += `<div id="cards">`
    build += `<h3>${data.results[index].original_title}</h3>`
    build += `<hr>`
    build += `<img src= "https://image.tmdb.org/t/p/w185/` + data.results[index].poster_path + '">' 
    build += `<h3> ${data.results[index].release_date}</h3> `
    build += `<h3> ${data.results[index].popularity}</h3> `
    build += `<h3>${data.results[index].overview}</h3>`
    build += `</div>`
  
  }
  output.innerHTML = build;
}

 //https://api.themoviedb.org/3/search/movie?api_key=35e53784f0035564c83a035ddcddfeff&query=spiderman