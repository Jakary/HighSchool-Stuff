function displayInfo(){
  var output = document.getElementById("output");
  var race= document.getElementById("race").value;
  var color = document.getElementById("color").value;
  var build = "";
  for(let index=0;index<data.items.length;index++){
    if(data.items[index].race == race){
      if(data.items[index].eyes == eyes){
    build+=`<div class="cards">`
    build+=`<p>${data.items[index].title}</p>`
    build+=`</div>`
    build+=`<div class="cards2">`
     build+=`<p>${data.items[index].sex}</p>`
      build+=`<p>${data.items[index].nationality}</p>`
       build+=`<p>${data.items[index].reward_text}</p>`
     build+=`</div>`
      }
    }
  }
  output.innerHTML=build;
}