function forecast(){
  var output = document.getElementById("output");
  var t = documnet.getElementById("t").value;
  var p = documnet.getElementById("p").value;
  var r = documnet.getElementById("r").value/100;
  var build = "<table>"
  for(var i = 1;i<=t;i++){
    var a = p*Math.pow(1+r,i);
    build+= `<tr><td>${i+1}</td>`
    build+=`<td> ${a.toFixed(2)}</td></tr>`
    console.log(a);
  }
  build +="</table>"
  output.innerHTML = build;

}