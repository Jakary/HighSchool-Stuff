var num1,num2;

function displayQuestion(){
  var question = document.getElementById("question");
  num1 = Math.floor(Math.random()*10+1);
  num2 = Math.floor(Math.random()*10+1);

  question.innerHTML = num1 + "+" + num2 +"=?";

}

function check(){
  var answer = document.getElementById("answer");
  if(answer.value == num1 + num2 ){
   output.innerHTML ="Great";
  }

}