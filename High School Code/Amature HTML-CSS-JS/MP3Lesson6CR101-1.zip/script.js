function displayInfo(){
  let failures = 0;
   for(let index = 0;index<data.length;index++){
     if(data[index].Grade<65){
       failures++;
     }
   }
   console.log(failures);
   failuresBySubject();
}

function failuresBySubject(){
  let M=0,U=0,H=0,A=0,F=0,E=0,S=0;
  for(let index=0;index<data.length;index++){
    if(data[index].Course[0]=="M" && data[index].Grade<65){
    M++;}
    if(data[index].Course[0]=="S" && data[index].Grade<65){
    S++;}
    if(data[index].Course[0]=="H" && data[index].Grade<65){
    H++;}
    if(data[index].Course[0]=="E" && data[index].Grade<65){
    E++;}
    if(data[index].Course[0]=="A" && data[index].Grade<65){
    A++;}
    if(data[index].Course[0]=="U" && data[index].Grade<65){
    U++;}
    if(data[index].Course[0]=="F" && data[index].Grade<65){
    F++;}

  }
  document.write("A-"+A+"<br>");
  document.write("S-"+S+"<br>");
  document.write("H-"+H+"<br>");
  document.write("E-"+E+"<br>");
  document.write("M-"+M+"<br>");
  document.write("U-"+U+"<br>");
  document.write("F-"+F+"<br>");
  document.write(M+A+U+F+E+H+S);

  

}

function failuresByGradeLevel(){
  let fg = [0,0,0,0],grade;
  for(let index=0;index<data.length;index++){
    grade = data[index].Level-9;
    if(data[index].Grade,65);
    fg[grade]++;
  }
  for(let index=0;index<fg.length;index++){
    document.write(fg[index]+"<br>");
  }
  
}
 