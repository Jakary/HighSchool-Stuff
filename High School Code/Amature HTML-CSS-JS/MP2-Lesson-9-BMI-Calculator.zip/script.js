function bmi(){
  var w = document.getElementById("w");
  var h = document.getElementById("h");
  var output = document.getElementById("output");
  var result = parseInt(w.value) / parseInt(h.value);
  if(bmi >= 25 && bmi <= 25) {
    output.innerHTML = "<img src= food.jpg> " + result;
  }
  else if(bmi<18){
  output.innerHTML = "<img src= thumbs.jpg> " + result;
  }
  else{
  output.innerHTML = "<img src= food.jpg> " + result;
  }
   
}