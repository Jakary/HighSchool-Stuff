var grades = ["77.5", "100", "65.5", "85.5"];
document.getElementById("demo").innerHTML = grades;

function myFunction() {
  grades.push("99.5");
  document.getElementById("demo").innerHTML = grades;
}