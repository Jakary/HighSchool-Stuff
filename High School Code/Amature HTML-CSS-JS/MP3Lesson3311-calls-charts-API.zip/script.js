var chartData = [
            ["Sedans", 10],
            ["Taxis", 20],
            ["SUVs", 30]			
        ];
function showChart(){
  c3.generate({
    bindto: "#myChart",
    data: {
      columns: chartData, //end columns
      type: "bar"				
    } //end data
  }); // end generate	
}

function displayInfo(){
  var queens = 0, bronx = 0, brooklyn = 0;
  var manhattan = 0, staten_island = 0;
  var noise = 0;
  for(var index = 0; index < data.length; index++){
    if( data[index].borough == "QUEENS" ){
      queens += 1;
    }else if( data[index].borough == "BRONX" ){
      bronx += 1;
    }else if( data[index].borough == "BROOKLYN" ){
      brooklyn += 1;
    }else if( data[index].borough == "MANHATTAN" ){
      manhattan += 1;
    }else if( data[index].borough == "STATEN ISLAND" ){
      staten_island += 1;
    }else{
      //console.log(data[index]);
    }
    if(data[index].complaint_type.includes("Noise")){
      noise++;
    }
    //document.write(data[index].complaint_type + "<br>");
  }
  console.log(queens + " / " + data.length );
  console.log(bronx + " / " + data.length );
  console.log(brooklyn + " / " + data.length );
  console.log(manhattan + " / " + data.length );
  console.log(staten_island + " / " + data.length );
  console.log(noise + " / " + data.length );
  chartData = [
            ["Queens", queens],
            ["Bronx", bronx],
            ["Brooklyn", brooklyn],
            ["Manhattan", manhattan],
            ["Staten Island",staten_island]			
        ];
  c3.generate({
    bindto: "#myChart",
    data: {
      columns: chartData, //end columns
      type: "pie"				
    } //end data
  });
}
