function add(){
  var output = document.getElementById("output");
  var number = document.getElementById("number1");
  var number = document.getElementById("number2");
  var answer = parseInt(number1.value) + parseInt(number2.value);

  var answer = parseFloat(number1.value) + parseFloat(number2.value);
  output.innerHTML="Answer: " + answer 
}

function subtract(){
  var output = document.getElementById("output");
  var number = document.getElementById("number1");
  var number = document.getElementById("number2");
  var answer = parseInt(number1.value) - parseInt(number2.value);

  var answer = parseFloat(number1.value) - parseFloat(number2.value);
  output.innerHTML="Answer: " + answer 
}