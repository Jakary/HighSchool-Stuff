function check(){
  var l=document.getElementById("level").value;
  var c=document.getElementById("credits").value;
  var output=document.getElementById("output");
  if(l==9 && c>=8){
    output.innerHTML="OnTrack"
  }else if(l==10 && c>=20){
    output.innerHTML="OnTrack"
  }else if(l==11 && c>=30){
    output.innerHTML="OnTrack"
  }else if(l==12 && c>=44){
    output.innerHTML="Able to Graduate"
  }else{
    output.innerHTML="OffTrack"
  }
}

function check2(){
  var a =document.getElementById("a").checked;
  var b =document.getElementById("b").checked;
  var c =document.getElementById("c").checked;
  var d =document.getElementById("d").checked;
  var e =document.getElementById("e").checked;
  var output2 =document.getElementById("output2");
  if(a==true && b==true && c==true && d==true && e==true){
    output2.innerHTML=" Congrats You Are Able to Graduate :)"
  }else{
    output2.innerHTML="Sorry You Are Unable to Graduate :("
  }
}
