function displayInfo(){
  let output = document.getElementById("output");
  let build="";
  build+=`<div class="crash">`
  build+=`<h1>Car Crash Info </h1>`
  build+=`<h1>By:Jakary Ivery</h1>`
  for(let index=0;index<data.length;index++){
    build+=`<div class="cards">`
    build+=`<h1>${data[index].state_registration}</h1>`
    build+=`<p>${data[index].vehicle_type}</p>`
    build+=`<p>${data[index].point_of_impact}</p>`
    build+=`<p>${data[index].vehicle_damage}</p>`
    build+=`<p>${data[index].pre_crash}</p>`
    build+=`<p>${data[index].travel_direction}</p>`
    build+=`<p>${data[index].contributing_factor_1}</p>`
    build+=`<p>${data[index].unique_id}</p>`
    build+=`</div>`
  }
  output.innerHTML=build;
}