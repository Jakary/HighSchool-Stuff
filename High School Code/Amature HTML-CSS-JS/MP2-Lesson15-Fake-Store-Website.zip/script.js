function purchase(){  
  var qty= document.getElementById("qty");
  var o = document.getElementById("output");
  var subtotal = 5.99 * qty.value;

  if (subtotal>= 10){
    o.innerHTML="Discount of 5%"
    subtotal = 10-3

  }
  
  var tax = subtotal * 0.0875
  
  var total = subtotal + tax 

  o.innerHTML = "$10" +"        " + "Quantity" + " " + qty.value + "=" + total

  var build =""
  build += `<div id="reciept">`
  build += `<h2>Super Duper Cheap Games</h2>`
  build += `<hr>`
  build += `<p>OVERWATCH $9.99 qty ${qty.value}</p>`
  build += `<hr>`
  build += `<p>Tax (8.875%)${tax.value}</p>`
  build += `<hr>`
  build += `<p>Total${total.value}</p>`
  build += `</div>`
  output.innerHTML = build;
  



}

