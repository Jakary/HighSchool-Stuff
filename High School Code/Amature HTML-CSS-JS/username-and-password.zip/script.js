function greeting(){
  var output =document.getElementById("output");
  var name =document.getElementById("name");

  output.innerHTML="hello"+name.value;
}